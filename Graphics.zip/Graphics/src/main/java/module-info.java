module org.example.graphics {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.apache.poi.ooxml;



    opens org.example.graphics to javafx.fxml;
    exports org.example.graphics.Task_4;
    exports org.example.graphics.Task_1;
    exports org.example.graphics.Task_2;
    exports org.example.graphics.Task_3;
    opens org.example.graphics.Task_4 to javafx.fxml;
    opens org.example.graphics.Task_3 to javafx.fxml;
    opens org.example.graphics.Task_2 to javafx.fxml;
    opens org.example.graphics.Task_1 to javafx.fxml;
    exports org.example.graphics;
}