package org.example.graphics.Task_1;

import javafx.scene.control.Alert;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExportToExel {
    private static Connection connection;
    private static String tablename;
    private static ConnectionDB dbManager;
    private static CreateDB tbmanager;

    private static void showAlert(Alert.AlertType alertType, String tittle, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(tittle);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void exportToExcel() {
        try {
            dbManager = new ConnectionDB();
            tbmanager = new CreateDB();
            tablename = tbmanager.getTablename();
            connection = dbManager.getConnection();
            XSSFWorkbook workbook = null;
            try {
                if (connection == null || tablename == null || tablename.isEmpty()) {
                    throw new IllegalArgumentException("Не указаны обязательные параметры");
                }

                String query = "SELECT * FROM " + tablename;
                PreparedStatement ps = connection.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                workbook = new XSSFWorkbook();
                XSSFSheet sheet = workbook.createSheet(tablename);
                XSSFRow headerRow = sheet.createRow(0);


                headerRow.createCell(0).setCellValue("ID");
                headerRow.createCell(1).setCellValue("1 строка");
                headerRow.createCell(2).setCellValue("2 строка");
                headerRow.createCell(3).setCellValue("Перевёрнутая 1 строка");
                headerRow.createCell(4).setCellValue("Перевёрнутая 2 строка");
                headerRow.createCell(5).setCellValue("Слитые строки");

                int rowNum = 1;

                while (rs.next()) {
                    XSSFRow row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(rs.getInt("id"));
                    row.createCell(1).setCellValue(rs.getString("STR1"));
                    row.createCell(2).setCellValue(rs.getString("STR2"));
                    row.createCell(3).setCellValue(rs.getString("STR1TURN"));
                    row.createCell(4).setCellValue(rs.getString("STR2TURN"));
                    row.createCell(5).setCellValue(rs.getString("CONSTR"));
                }


                for (int i = 0; i < 6; i++) {
                    sheet.autoSizeColumn(i);
                }


                try (FileOutputStream fileOut = new FileOutputStream(tablename + ".xlsx")) {
                    workbook.write(fileOut);
                    showAlert(Alert.AlertType.INFORMATION, "Успешно!", "Таблица сохранена в файл " + tablename + ".xlsx");
                    System.out.println();
                }

            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Ошибка!", "Ошибка при экспорте в Excel: " + e.getMessage());

            } finally {
                try {
                    if (workbook != null) {
                        workbook.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка!", "Ошибка при закрытии ресурсов: " + e.getMessage());

                }
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Таблица не создана.");
        }
    }
}