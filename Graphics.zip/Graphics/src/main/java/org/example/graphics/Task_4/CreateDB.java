package org.example.graphics.Task_4;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.sql.Statement;

import static org.example.graphics.Task_4._MainApp.showAlert;
import static org.example.graphics.Task_4.ConnectionDB_.con;

public class CreateDB {

    private static boolean Tableon = false;
    private static String tablename;

    public static void create() throws SQLException {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);

        window.setTitle("Создание таблицы");

        Button save = new Button("Сохранить");
        TextField text = new TextField();

        VBox layout = new VBox(10, text, save);
        Scene scene = new Scene(layout, 300, 250);

        save.setOnAction(actionEvent -> {

            tablename = text.getText();

            String query = "CREATE TABLE IF NOT EXISTS " + tablename +
                    " (ID SERIAL PRIMARY KEY, " +
                    "NAME VARCHAR(255) NOT NULL, " +
                    "AGE int, " +
                    "SALARY int)";

            try (Statement stmt = con.createStatement()) {
                stmt.executeUpdate(query);
                showAlert(Alert.AlertType.INFORMATION, "Успех", "Операция выполненна успешно!");
                Tableon = true;
                window.close();
            } catch (SQLException e) {
                showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректные символы!");
            }
        });

        window.setScene(scene);
        window.showAndWait();
    }

    public static String getTablename() {
        return tablename;
    }

    public static boolean getTableon() {
        return Tableon;
    }
}
