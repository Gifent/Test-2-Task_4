package org.example.graphics.Task_4;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionDB_ {

    protected static String postgreSQL = "jdbc:postgresql://localhost:5432/postgres";
    public static Connection con;

    public static void connect() {
        try {
            con = DriverManager.getConnection(postgreSQL, "postgres", "pam311007");
            System.out.println("Подключение выполненно успешно!");
        } catch (Exception e) {
            System.out.println("Ошибка подключения: " + e);
        }
    }
}