package org.example.graphics.Task_1;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.example.graphics.Task_4.ConnectionDB_.con;

public class CreateDB {
    private static String tablename;

    private static void showAlert(Alert.AlertType alertType, String tittle, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(tittle);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static boolean readValidTableName(String name) {
        return name.matches("[A-Za-zА-Яа-я_][A-Za-zА-Яа-я0-9_]*");
    }

    public static void showTables() throws SQLException {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Созданные таблицы");

        TextArea tableList = new TextArea();
        tableList.setEditable(false);
        Button closeButton = new Button("Закрыть");

        VBox layout = new VBox(10);

        layout.getChildren().addAll(
                new Label("Список созданных таблиц:"),
                tableList,
                closeButton
        );

        closeButton.setOnAction(e -> window.close());

        try (Statement stmt = ConnectionDB.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")) {

            StringBuilder tables = new StringBuilder();
            while (rs.next()) {
                tables.append(rs.getString("table_name")).append("\n");
            }

            tableList.setText(tables.toString());

        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setHeaderText("Произошла ошибка при получении списка таблиц");
            alert.setContentText("Ошибка: " + e.getMessage());
            alert.showAndWait();
        }

        Scene scene = new Scene(layout, 300, 400);
        window.setScene(scene);
        window.showAndWait();
    }

    public static void create() throws SQLException {
        Stage window = new Stage();

        window.initModality(Modality.APPLICATION_MODAL);

        window.setTitle("Создание таблицы");
        TextField text;
        try {
            text = new TextField();
            text.setPromptText("Название таблицы");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Button save = new Button("Сохранить");

        VBox layout = new VBox(10, text, save);
        Scene scene = new Scene(layout, 300, 250);

        save.setOnAction(actionEvent -> {
            String tablename1 = text.getText();
            if (!readValidTableName(tablename1)) {
                showAlert(Alert.AlertType.ERROR, "Ошибка!", "Некорректное название таблицы!");
                return;
            }
            tablename = tablename1;

            String query = "CREATE TABLE IF NOT EXISTS " + tablename1 +
                    "(ID SERIAL PRIMARY KEY, " +
                    "STR1 VARCHAR(1000), " +
                    "STR2 VARCHAR(1000), " +
                    "STR1TURN VARCHAR(1000), " +
                    "STR2TURN VARCHAR(1000), " +
                    "CONSTR VARCHAR(1000))";

            try (Statement stmt = ConnectionDB.getConnection().createStatement()) {
                stmt.executeUpdate(query);
                showAlert(Alert.AlertType.INFORMATION, "Успех", "Таблица успешно создана!");
                window.close();
            } catch (SQLException e) {
                showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректные символы!");
            }
        });

        window.setScene(scene);
        window.showAndWait();
    }

    public static String getTablename() {
        return tablename;
    }
}