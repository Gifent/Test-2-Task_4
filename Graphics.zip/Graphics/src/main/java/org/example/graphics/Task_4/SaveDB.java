package org.example.graphics.Task_4;

import javafx.scene.control.Alert;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.example.graphics.Task_4._MainApp.showAlert;
import static org.example.graphics.Task_4.ConnectionDB_.con;

public class SaveDB {

    public static void save() throws SQLException {
        if (CreateDB.getTableon()) {
            try {
                String tablename = CreateDB.getTablename();

                String query = "SELECT * FROM " + tablename;
                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                XSSFWorkbook workbook = new XSSFWorkbook();
                XSSFSheet sheet = workbook.createSheet(tablename);

                XSSFRow headerRow = sheet.createRow(0);
                headerRow.createCell(0).setCellValue("ID");
                headerRow.createCell(1).setCellValue("NAME");
                headerRow.createCell(2).setCellValue("AGE");
                headerRow.createCell(3).setCellValue("SALARY");

                int rowNum = 1;
                while (rs.next()) {
                    XSSFRow row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(rs.getInt("id"));
                    row.createCell(1).setCellValue(rs.getString("name"));
                    row.createCell(2).setCellValue(rs.getInt("age"));
                    row.createCell(3).setCellValue(rs.getInt("salary"));

                    for (int i = 0; i < 3; i++) {
                        sheet.autoSizeColumn(i);
                    }
                }

                try (FileOutputStream fileOut = new FileOutputStream(tablename + ".xlsx")) {
                    workbook.write(fileOut);
                } catch (Exception e) {
                }

                showAlert(Alert.AlertType.INFORMATION, "Успех", "Таблица успешно экспортирована!");
            } catch (Exception e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Ошибка", "Ошибка экспорта таблицы");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Таблица не создана!");
        }
    }
}
