package org.example.graphics.Task_4;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.example.graphics.Task_4.ConnectionDB_.con;

public class OutputNames {

    public static void display() throws SQLException {
        try (Statement stmt = con.createStatement()) {
            String query = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'";
            ResultSet rs = stmt.executeQuery(query);

            ObservableList<TableData> tablelist = FXCollections.observableArrayList();

            int id = 1;
            while (rs.next()) {
                tablelist.add(new TableData(id++, rs.getString("table_name")));
            }

            TableView<TableData> tableView = new TableView<>();
            tableView.setItems(tablelist);

            TableColumn<TableData, Integer> idColumn = new TableColumn<>("id");
            TableColumn<TableData, String> nameColumn = new TableColumn<>("name");

            idColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().id()));
            nameColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().tablename()));

            tableView.getColumns().addAll(idColumn, nameColumn);


            Stage window = new Stage();
            window.setTitle("Таблицы");
            Scene scene = new Scene(tableView);
            window.setScene(scene);
            window.showAndWait();
        }
    }
}