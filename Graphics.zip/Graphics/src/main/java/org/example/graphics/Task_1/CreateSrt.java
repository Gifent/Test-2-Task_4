package org.example.graphics.Task_1;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateSrt {

    private static Connection connection;
    private static String tablename;
    private static ConnectionDB dbManager;
    private static CreateDB tbmanager;
    private static int id = 0;

    private static void showAlert(Alert.AlertType alertType, String tittle, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(tittle);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static boolean isValidString(String name3) {
        return name3 != null && !name3.isEmpty() && !name3.contains(" ") && name3.matches("^[^\\s]+$");
    }

    public static void createRows() throws SQLException {
        dbManager = new ConnectionDB();
        tbmanager = new CreateDB();
        tablename = tbmanager.getTablename();
        connection = dbManager.getConnection();

        id += 1;


        String query = "INSERT INTO " + tablename + " (STR1, STR2) VALUES (?, ?)";

        PreparedStatement ps = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Введите строки");
        TextField stroka1 = new TextField();
        TextField stroka2 = new TextField();
        stroka1.setPromptText("Первая строка");
        stroka2.setPromptText("Вторая строка");

        Button save = new Button("Сохранить");


        save.setOnAction(actionEvent -> {
            String str1 = stroka1.getText().replaceAll("\\n", "");
            String str2 = stroka2.getText().replaceAll("\\n", "");
            if (str1.isEmpty() || str2.isEmpty() || str1.length() < 50 || str2.length() < 50) {
                showAlert(Alert.AlertType.ERROR, "Ошибка!", "Строки пустые или длина строки меньше 50 символов");
                return;
            }


            try {
                ps.setString(1, str1);
                ps.setString(2, str2);
                ps.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Успешно", "Строки добавлены в БД");

                window.close();
            } catch (SQLException e) {
                showAlert(Alert.AlertType.ERROR, "Создайте таблицу!", "Перед работой со строками создайте таблицу");

            }
        });
        VBox layout = new VBox(10, stroka1, stroka2, save);
        Scene scene = new Scene(layout, 300, 250);
        window.setScene(scene);
        window.showAndWait();
    }
}