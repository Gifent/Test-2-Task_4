package org.example.graphics.Task_3;

public class ArrayPy
{
    protected static int[] array;

    public ArrayPy()
    {
        array = null;
    }

    public static void clearCurrentArray(){array = null;}
    public int[] getArray(){return array;}
    public void setArray(int[] setArray){array = setArray;}
}
