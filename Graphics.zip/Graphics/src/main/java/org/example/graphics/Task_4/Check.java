package org.example.graphics.Task_4;

public class Check {

    public static String readValidText(String name) {
            name = name.trim().toLowerCase();
            if (name.matches("[a-zа-я]+")) {
                return name;
            }
        return "";
    }
}
