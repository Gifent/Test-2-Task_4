package org.example.graphics.Task_2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class HelloApplication1 extends Application {
    private static DatabaseManager database = new DatabaseManager("postgres","pam311007");
    private static ArrayPy array = new ArrayPy();
    private static Matrix matrix = new Matrix();
    private int[][] mat = new int[7][7];
    private int[][] mat2 = new int[7][7];
    private boolean isIzMatFill1 = true;
    private boolean isIzMatFill2 = true;
    private int count_itter1 = -1;
    private int count_itter2 = -1;
    private TextField inputField;
    private static String strmat1 = " ";
    private static String strmat2 = " ";
    public static String convertArrayToString1(int[][] arr)
    {
        String result = "| ";
        for(int i = 0; i < 7; i++)
        {
            for(int j = 0; j < 7; j++)
            {
                result += arr[i][j];
                result += " ";
            }
            result += "|";
            if (i != 6) {
                result += "\n";
                result += "| ";
            }
        }
        return result;
    }

    private static boolean isValidTableName(String name1) {
        return name1.matches("^[a-zA-Z][a-zA-Z0-9_]*$");
    }

    private static boolean isValidInteger(String name2) {
        return name2.matches("^([-0]*[0-9]*)$");
    }

    private static boolean isValidString(String name3) {
        return name3 != null && !name3.isEmpty() && !name3.contains(" ") && name3.matches("^[^\\s]+$");
    }

    private static boolean isValidInteger_2(String name4){
        return name4.matches("^([1-2])$");
    }

    private static boolean isValidInput(String str) {
        return !str.isEmpty() && !(str.contains(" ") || str.contains("\t") || str.contains("\n") || str.contains("\r"));
    }

    private void disableallbnts(Button[] array) {
        for(int i = 0; i < array.length; i++) {
            array[i].setDisable(true);
        }
    }

    private void undisableallbnts(Button[] array) {
        for(int i = 0; i < array.length; i++) {
            array[i].setDisable(false);
        }
    }

    @Override
    public void start(Stage stage) throws IOException, SQLException {
        database.connect();
        stage.setTitle("Task №2");
        Button btn1 = new Button("Вывести все таблицы");
        Button btn2 = new Button("Создать таблицу");
        Button btn3 = new Button("Ввести матрицы");
        Button btn4 = new Button("Перемножить матрицы");
        Button btn5 = new Button("Сохранить данные в excel");
        Button[] btns = {btn1,btn2,btn3,btn4,btn5};
        disableallbnts(btns);

        inputField = new TextField();
        inputField.setVisible(false);
        inputField.setMaxWidth(300);

        VBox inputBox = new VBox(10, inputField);
        inputBox.setPadding(new Insets(20));
        inputBox.setAlignment(Pos.BOTTOM_CENTER);

        TextArea concole = new TextArea();
        concole.setEditable(false);
        concole.setMaxSize(500,700);


        VBox buttonMenu = new VBox(10, btn1,btn2,btn3,btn4,btn5);
        buttonMenu.setPadding(new Insets(10));
        buttonMenu.setAlignment(Pos.CENTER);

        BorderPane root = new BorderPane();
        root.setBottom(inputBox);
        root.setLeft(buttonMenu);
        root.setCenter(concole);

        Scene scene = new Scene(root,800,800);
        stage.setScene(scene);
        stage.show();

        btn1.setOnAction(e-> {
            concole.appendText("Все таблицы\n");
            List<String> tablesList= database.getTablesList();
            for (String tablename : tablesList) {
                concole.appendText(tablename + "\n");
            }
        });

        btn2.setOnAction(e -> {
            disableallbnts(btns);
            array.setArray1(null);
            array.setArray2(null);
            concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
            inputField.setPromptText("Только буквы, цифры и _");
            inputField.setVisible(true);
            inputField.clear();
            inputField.requestFocus();

            inputField.setOnAction(event -> {
                String input = inputField.getText().trim();
                if (isValidInput(input) && !input.isEmpty()) {
                    try {
                        database.createCalculationsTable(input);
                        concole.appendText("Таблица создана: " + input + "\n");
                        inputField.setVisible(false);
                        inputField.setOnAction(null);
                        undisableallbnts(btns);
                        if ((array.getArray1() == null) || (array.getArray2() == null))
                        {
                            btn4.setDisable(true);
                        }
                    } catch (SQLException b) {
                        concole.appendText("Ошибка БД: " + b.getMessage() + "\n");
                        concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                        inputField.clear();
                    }
                } else {
                    concole.appendText("Неверное название таблицы\n");
                    concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                    inputField.clear();
                }
            });
        });

        btn3.setOnAction(e-> {
            disableallbnts(btns);
            count_itter1 = 0;
            count_itter2 = 0;
            isIzMatFill1 = false;
            isIzMatFill2 = false;
            strmat1 = " ";
            strmat2 = " ";
            mat = new int[7][7];
            mat2 = new int[7][7];
            concole.appendText("Ввод матрицы 1\n");
            inputField.setPromptText("Элемент 1: введите число");
            inputField.setVisible(true);
            inputField.clear();
            inputField.requestFocus();

            inputField.setOnAction(event -> {
                String input = inputField.getText().trim();
                if (isIzMatFill1 == false) {
                    if (isValidInteger(input) && !input.isEmpty()) {
                        mat[count_itter1][count_itter2] = Integer.parseInt(input);
                        concole.appendText("Элемент [" + (count_itter1 + 1) + "][" + (count_itter2 + 1) + "]" + input + "\n");
                        if (count_itter2 == 6) {
                            count_itter2 = -1;
                            count_itter1++;
                        }
                        count_itter2++;

                        if ((count_itter1 < 7) & (count_itter2 < 7)) {
                            inputField.setPromptText("Элемент [" + (count_itter1 + 1) + "][" + (count_itter2 + 1) + "]" + ": введите число");
                            inputField.clear();
                        } else {
                            strmat1 = convertArrayToString1(mat);
                            concole.appendText("Матрица 1 заполнена: \n" + strmat1 + "\n");
                            array.setArray1(mat);
                            count_itter1 = 0;
                            count_itter2 = 0;
                            isIzMatFill1 = true;
                            concole.appendText("\nВвод Матрицы 2\n");
                        }
                    } else {
                        concole.appendText("Неверное число\n");
                        inputField.clear();
                    }
                } else {
                    if (isValidInteger(input) && !input.isEmpty()) {
                        try {

                            mat2[count_itter1][count_itter2] = Integer.parseInt(input);
                            concole.appendText("Элемент [" + (count_itter1 + 1) + "][" + (count_itter2 + 1) + "]" + input + "\n");
                            if (count_itter2 == 6) {
                                count_itter2 = -1;
                                count_itter1++;
                            }
                            count_itter2++;


                            if ((count_itter1 < 7) & (count_itter2 < 7)) {
                                inputField.setPromptText("Элемент [" + (count_itter1 + 1) + "][" + (count_itter2 + 1) + "]" + ": введите число");
                                inputField.clear();
                            } else {
                                strmat2 = convertArrayToString1(mat2);
                                concole.appendText("Матрица 2 заполнена: \n" + strmat2 + "\n");
                                array.setArray2(mat);
                                database.saveCalculation(strmat1, strmat2, " ");
                                count_itter1 = -1;
                                count_itter2 = -1;
                                inputField.setVisible(false);
                                inputField.setOnAction(null);
                                undisableallbnts(btns);
                                if ((array.getArray1() == null) || (array.getArray2() == null))
                                {
                                    btn4.setDisable(true);
                                }
                            }
                        } catch (SQLException b) {
                            concole.appendText("Ошибка сохранения: " + b.getMessage() + "\n");
                            inputField.clear();
                        }
                    } else {
                        concole.appendText("Неверное число\n");
                        inputField.clear();
                    }
                }

            });
        });

        btn4.setOnAction(e-> {
            String result1 = convertArrayToString1(matrix.Production());
            concole.appendText("Перемноженная матрица \n");
            concole.appendText(result1 + "\n");
            try {
                database.updateCalculation(result1);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });

        btn5.setOnAction(e->
        {
            database.exportAllTablesToExcel();
            concole.appendText("Таблицы сохранены");
        });


        concole.appendText("Подключение к базе данных произошло успешно\n");
        concole.appendText("Введите название таблицы(только буквы, цифры и _)\n");
        inputField.setVisible(true);
        inputField.requestFocus();

        inputField.setOnAction(event -> {
            String input = inputField.getText().trim();
            if (isValidInput(input) && !input.isEmpty()) {
                try {
                    database.createCalculationsTable(input);
                    concole.appendText("Таблица создана: " + input + "\n");
                    inputField.setVisible(false);
                    inputField.setOnAction(null);
                    undisableallbnts(btns);
                    if ((array.getArray1() == null) || (array.getArray2() == null))
                    {
                        btn4.setDisable(true);
                    }
                } catch (SQLException e) {
                    concole.appendText("Ошибка БД: " + e.getMessage() + "\n");
                    concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                    inputField.clear();
                }
            } else {
                concole.appendText("Неверное название таблицы\n");
                concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                inputField.clear();
            }
        });
    }
}

