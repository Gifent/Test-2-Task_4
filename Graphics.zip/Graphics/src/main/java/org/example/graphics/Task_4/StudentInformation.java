package org.example.graphics.Task_4;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.PreparedStatement;
import java.sql.SQLException;


import static org.example.graphics.Task_4._MainApp.showAlert;
import static org.example.graphics.Task_4.ConnectionDB_.con;

class Student {
    private String name;
    private int age;

    public void inf() throws SQLException {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

class Worker extends Student {
    private int salary;

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
}


public class StudentInformation extends Worker {
    @Override
    public void inf() throws SQLException {

        if (CreateDB.getTableon() == true) {

            TextField name = new TextField();
            TextField age = new TextField();
            TextField salary = new TextField();

            name.setPromptText("Введите имя");
            age.setPromptText("Введите возраст");
            salary.setPromptText("Введите доход");

            Button save = new Button("Сохранить");

            VBox box = new VBox(10, name, age, salary, save);

            Stage window = new Stage();
            window.setTitle("Студент");
            Scene scene = new Scene(box, 300, 200);
            window.setScene(scene);

            save.setOnAction(actionEvent -> {
                String tablename = CreateDB.getTablename();

                String name_save = Check.readValidText(name.getText());
                int ageValue;
                int salaryValue;

                try {
                    ageValue = Integer.parseInt(age.getText());
                    salaryValue = Integer.parseInt(salary.getText());
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректный ввод данных");
                    return;
                }


                try {

                    String query_update1 = "INSERT INTO " + tablename + " (name, age, salary) VALUES (?, ?, ?)";
                    PreparedStatement ps1 = con.prepareStatement(query_update1);
                    setName(name_save);
                    setAge(ageValue);
                    setSalary(salaryValue);
                    if (!getName().isEmpty())
                        ps1.setString(1, getName());
                    ps1.setInt(2, getAge());
                    ps1.setInt(3, getSalary());
                    ps1.executeUpdate();

                    showAlert(Alert.AlertType.INFORMATION, "Успех", "Данные успешно внесены");
                    window.close();
                } catch (SQLException e) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректный ввод данных");
                }
            });

            window.showAndWait();
        } else {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Таблица не создана!");
        }
    }
}