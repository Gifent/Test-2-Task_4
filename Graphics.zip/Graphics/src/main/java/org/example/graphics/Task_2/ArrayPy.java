package org.example.graphics.Task_2;

public class ArrayPy
{
    protected static int[][] array1;
    protected static int[][] array2;

    public ArrayPy()
    {
        array1 = null;
        array2 = null;
    }

    public static void clearCurrentArray1(){array1 = null;}
    public int[][] getArray1(){return array1;}
    public static void clearCurrentArray2(){array2 = null;}
    public int[][] getArray2(){return array2;}
    public void setArray1(int[][] setArray){array1 = setArray;}
    public void setArray2(int[][] setArray){array2 = setArray;}
}
