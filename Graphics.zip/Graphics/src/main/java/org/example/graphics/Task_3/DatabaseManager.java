package org.example.graphics.Task_3;

import java.sql.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DatabaseManager {
    private Connection con;
    private List<String> tablelist = new ArrayList<>();
    private String currenttable = "";
    private String url;
    private String user;
    private String password;

    public DatabaseManager(String user, String password) {
        this.url = "jdbc:postgresql://localhost:5432/postgres";
        this.user = user;
        this.password = password;
    }

    public void connect() throws SQLException
    {
        con = DriverManager.getConnection(url, user, password);
        loadExistingTables();
    }

    private void loadExistingTables() throws SQLException {
        DatabaseMetaData metaData = con.getMetaData();
        ResultSet rs = metaData.getTables(null, null, "%", new String[]{"TABLE"});

        while (rs.next()) {
            String tableName = rs.getString("TABLE_NAME");
            if (!tablelist.contains(tableName)) {
                tablelist.add(tableName);
            }
        }
    }

    public void createCalculationsTable(String tablename) throws SQLException {
        String sql = String.format("""
            CREATE TABLE IF NOT EXISTS %s (
                id SERIAL PRIMARY KEY,
                array_data VARCHAR(2000) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """, tablename);

        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sql);

            if (!tablelist.contains(tablename)) {
                tablelist.add(tablename);
            }

            currenttable = tablename;
            System.out.println("Таблица '" + tablename + "' создана");
        }
    }

    public void saveCalculation(String array) throws SQLException {

        String sql = String.format("""
            INSERT INTO %s (array_data)
            VALUES (?)
        """, currenttable);

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, array);

            pstmt.executeUpdate();
        }
    }

    public List<String> getTablesList() {
        return new ArrayList<>(tablelist);
    }

    public String getCurrentTable() {
        return currenttable;
    }

    public void setCurrentTable(String tableName) {
        if (tablelist.contains(tableName)) {
            currenttable = tableName;
        }
    }

    private class CalculationRecord {
        private int id;
        private String array;
        private Timestamp createdAt;

        public CalculationRecord(int id, String array,
                                 Timestamp createdAt) {
            this.id = id;
            this.array = array;
            this.createdAt = createdAt;
        }

        public int getId() { return id; }
        public String getArray() { return array; }
        public Timestamp getCreatedAt() { return createdAt; }
    }

    private List<CalculationRecord> getCalculationsFromTable(String tableName) throws SQLException {
        List<CalculationRecord> records = new ArrayList<>();

        String sql = "SELECT * FROM " + tableName + " ORDER BY id";

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CalculationRecord record = new CalculationRecord(
                        rs.getInt("id"),
                        rs.getString("array_data"),
                        rs.getTimestamp("created_at")
                );
                records.add(record);
            }
        }

        return records;
    }

    public void exportAllTablesToExcel() {
        try (Workbook workbook = new XSSFWorkbook()) {

            for (String tableName : tablelist) {
                createExcelSheet(workbook, tableName);
            }

            new File("exports").mkdirs();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String timestamp = dateFormat.format(new Date());
            String filename = "exports/calculations_" + timestamp + ".xlsx";

            try (FileOutputStream fos = new FileOutputStream(filename)) {
                workbook.write(fos);
                System.out.println("Все таблицы экспортированы в: " + filename);
            }

        } catch (Exception e) {
            System.out.println("Ошибка экспорта в Excel: " + e.getMessage());
        }
    }

    private void createExcelSheet(Workbook workbook, String tableName) {
        Sheet sheet = workbook.createSheet(tableName);

        Row headerRow = sheet.createRow(0);
        String[] headers = {"ID", "Массив","Дата"};

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        try {
            List<CalculationRecord> data = getCalculationsFromTable(tableName);
            int rowNum = 1;

            for (CalculationRecord record : data) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(record.getId());
                row.createCell(1).setCellValue(record.getArray());

                if (record.getCreatedAt() != null) {
                    row.createCell(2).setCellValue(record.getCreatedAt().toString());
                } else {
                    row.createCell(2).setCellValue("");
                }
            }


            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

        } catch (SQLException e) {
            System.out.println("Ошибка при получении данных из таблицы '" + tableName + "': " + e.getMessage());
        }
    }


    public void printAllTables() throws SQLException {
        System.out.println("Таблицы:");
        for (String tableName : tablelist)
        {
            System.out.println(tableName);
        }
    }

    private int getLastCalculationId() throws SQLException {
        String sql = String.format("""
        SELECT id FROM %s 
        ORDER BY id DESC 
        LIMIT 1
    """, currenttable);

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next())
            {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    public void updateCalculation(String newArray) throws SQLException
    {
        int id = getLastCalculationId();
        String sql = String.format("""
        UPDATE %s 
        SET array_data = ?, created_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, currenttable);

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, newArray);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        }
    }

}