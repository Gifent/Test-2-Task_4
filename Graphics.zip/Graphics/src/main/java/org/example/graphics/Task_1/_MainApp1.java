package org.example.graphics.Task_1;

import javafx.application.Application;
import javafx.scene.Scene;

import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;

public class _MainApp1 extends Application {

    public static Integer id = 0;


    @Override
    public void start(Stage stage) {

        ConnectionDB.connect();
        stage.setTitle("Task №1");

        Button one = new Button("Вывести названия");
        Button two = new Button("Создать таблицу");
        Button three = new Button("Ввести строки");
        Button four = new Button("Инвертировать строки");
        Button five = new Button("Склеить строки");
        Button six = new Button("Сохранить");

        three.setDisable(true);
        four.setDisable(true);
        five.setDisable(true);
        six.setDisable(true);

        VBox layout = new VBox(10, one, two, three, four, five, six);
        Scene scene = new Scene(layout, 400, 340);
        stage.setScene(scene);
        stage.show();
        one.setOnAction(actionEvent -> {
            try {
                CreateDB.showTables();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        two.setOnAction(actionEvent -> {
            try {
                CreateDB.create();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            three.setDisable(false);
            six.setDisable(false);
        });

        three.setOnAction(actionEvent -> {
            try {
                CreateSrt.createRows();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            id += 1;
            four.setDisable(false);
            five.setDisable(false);
        });

        four.setOnAction(actionEvent -> {
            ReversSTR.revers(id);
        });

        five.setOnAction(actionEvent -> {
            try {
                StickSTR.Stick(id);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
        six.setOnAction(actionEvent -> {
            ExportToExel.exportToExcel();
        });
    }
}
