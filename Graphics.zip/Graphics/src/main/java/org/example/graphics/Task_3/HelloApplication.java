package org.example.graphics.Task_3;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;

public class HelloApplication extends Application {
    private static DatabaseManager database = new DatabaseManager("postgres","pam311007");
    private static ArrayPy array = new ArrayPy();
    private static Sort sort = new Sort();
    private int[] numsarray = new int[35];
    private int count_itter = -1;
    private TextField inputField;

    public static String convertArrayToString(int[] arr) {
        String result = "[";
        for(int i = 0; i < arr.length; i++) {
            result += arr[i];
            if (i < arr.length - 1) {
                result += ", ";
            }
        }
        result += "]";
        return result;
    }

    private static boolean isValidTableName(String name1) {
        return name1.matches("^[a-zA-Z][a-zA-Z0-9_]*$");
    }

    private static boolean isValidInteger(String name2) {
        return name2.matches("^([-0]*[0-9]*)$");
    }

    private static boolean isValidString(String name3) {
        return name3 != null && !name3.isEmpty() && !name3.contains(" ") && name3.matches("^[^\\s]+$");
    }

    private static boolean isValidInteger_2(String name4){
        return name4.matches("^([1-2])$");
    }

    private static boolean isValidInput(String str) {
        return !str.isEmpty() && !(str.contains(" ") || str.contains("\t") || str.contains("\n") || str.contains("\r"));
    }

    private void disableallbnts(Button[] array) {
        for(int i = 0; i < array.length; i++) {
            array[i].setDisable(true);
        }
    }

    private void undisableallbnts(Button[] array) {
        for(int i = 0; i < array.length; i++) {
            array[i].setDisable(false);
        }
    }

    @Override
    public void start(Stage stage) throws SQLException {
        database.connect();
        stage.setTitle("Task №3");
        Button btn1 = new Button("Вывести все таблицы");
        Button btn2 = new Button("Создать таблицу");
        Button btn3 = new Button("Ввести одномерный массив");
        Button btn4 = new Button("Отсортировать массив по убыванию");
        Button btn5 = new Button("Отсортировать массив по возрастанию");
        Button btn6 = new Button("Сохранить данные в excel");
        Button[] btns = {btn1,btn2,btn3,btn4,btn5,btn6};
        disableallbnts(btns);

        inputField = new TextField();
        inputField.setVisible(false);
        inputField.setMaxWidth(300);

        VBox inputBox = new VBox(10, inputField);
        inputBox.setPadding(new Insets(20));
        inputBox.setAlignment(Pos.BOTTOM_CENTER);

        TextArea concole = new TextArea();
        concole.setEditable(false);
        concole.setMaxSize(500,700);


        VBox buttonMenu = new VBox(10, btn1,btn2,btn3,btn4,btn5,btn6);
        buttonMenu.setPadding(new Insets(10));
        buttonMenu.setAlignment(Pos.CENTER);

        BorderPane root = new BorderPane();
        root.setBottom(inputBox);
        root.setLeft(buttonMenu);
        root.setCenter(concole);

        Scene scene = new Scene(root,800,800);
        stage.setScene(scene);
        stage.show();

        btn1.setOnAction(e-> {
            concole.appendText("Все таблицы\n");
            List<String> tablesList= database.getTablesList();
            for (String tablename : tablesList) {
                concole.appendText(tablename + "\n");
            }
        });

        btn2.setOnAction(e -> {
            disableallbnts(btns);
            array.setArray(null);
            concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
            inputField.setPromptText("Только буквы, цифры и _");
            inputField.setVisible(true);
            inputField.clear();
            inputField.requestFocus();

            inputField.setOnAction(event -> {
                String input = inputField.getText().trim();
                if (isValidInput(input) && !input.isEmpty()) {
                    try {
                        database.createCalculationsTable(input);
                        concole.appendText("Таблица создана: " + input + "\n");
                        inputField.setVisible(false);
                        inputField.setOnAction(null);
                        undisableallbnts(btns);
                        if (array.getArray() == null)
                        {
                            btn4.setDisable(true);
                            btn5.setDisable(true);
                        }
                    } catch (SQLException b) {
                        concole.appendText("Ошибка БД: " + b.getMessage() + "\n");
                        concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                        inputField.clear();
                    }
                } else {
                    concole.appendText("Неверное название таблицы\n");
                    concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                    inputField.clear();
                }
            });
        });

        btn3.setOnAction(e-> {
            disableallbnts(btns);
            count_itter = 0;
            numsarray = new int[35];
            concole.appendText("Ввод элементов массива\n");
            inputField.setPromptText("Элемент 1: введите число");
            inputField.setVisible(true);
            inputField.clear();
            inputField.requestFocus();

            inputField.setOnAction(event -> {
                String input = inputField.getText().trim();
                if (isValidInteger(input) && !input.isEmpty()) {
                    try {
                        numsarray[count_itter] = Integer.parseInt(input);
                        concole.appendText("Элемент " + (count_itter + 1) + ": " + input + "\n");
                        count_itter++;

                        if (count_itter < 35) {
                            inputField.setPromptText("Элемент " + (count_itter + 1) + ": введите число");
                            inputField.clear();
                        } else {
                            concole.appendText("Массив заполнен: " + convertArrayToString(numsarray) + "\n");
                            array.setArray(numsarray);
                            database.saveCalculation(convertArrayToString(numsarray));
                            inputField.setVisible(false);
                            inputField.setOnAction(null);
                            undisableallbnts(btns);
                            if (array.getArray() == null)
                            {
                                btn4.setDisable(true);
                                btn5.setDisable(true);
                            }
                            count_itter = -1;
                        }
                    } catch (SQLException b) {
                        concole.appendText("Ошибка сохранения: " + b.getMessage() + "\n");
                        inputField.clear();
                    }
                } else {
                    concole.appendText("Неверное число\n");
                    inputField.clear();
                }
            });
        });

        btn4.setOnAction(e-> {
            sort.bubbleSortDown();
            String line = convertArrayToString(array.getArray());
            concole.appendText("Отсортированный массив");
            concole.appendText(line + "\n");
            try {
                database.updateCalculation(line);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });

        btn5.setOnAction(e-> {
            sort.bubbleSortUp();
            String line = convertArrayToString(array.getArray());
            concole.appendText("Отсортированный массив");
            concole.appendText(line + "\n");
            try {
                database.updateCalculation(line);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });

        btn6.setOnAction(e->
        {
            database.exportAllTablesToExcel();
            concole.appendText("Таблицы сохранены");
        });


        concole.appendText("Подключение к базе данных произошло успешно\n");
        concole.appendText("Введите название таблицы(только буквы, цифры и _)\n");
        inputField.setVisible(true);
        inputField.requestFocus();

        inputField.setOnAction(event -> {
            String input = inputField.getText().trim();
            if (isValidInput(input) && !input.isEmpty()) {
                try {
                    database.createCalculationsTable(input);
                    concole.appendText("Таблица создана: " + input + "\n");
                    inputField.setVisible(false);
                    inputField.setOnAction(null);
                    undisableallbnts(btns);
                    if (array.getArray() == null)
                    {
                        btn4.setDisable(true);
                        btn5.setDisable(true);
                    }
                } catch (SQLException e) {
                    concole.appendText("Ошибка БД: " + e.getMessage() + "\n");
                    concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                    inputField.clear();
                }
            } else {
                concole.appendText("Неверное название таблицы\n");
                concole.appendText("Введите название таблицы(только буквы, цифры и _):\n");
                inputField.clear();
            }
        });
    }
}