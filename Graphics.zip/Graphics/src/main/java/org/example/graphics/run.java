package org.example.graphics;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.graphics.Task_1._MainApp1;
import org.example.graphics.Task_3.HelloApplication;
import org.example.graphics.Task_2.HelloApplication1;
import org.example.graphics.Task_4._MainApp;

import java.io.IOException;
import java.sql.SQLException;

public class run extends Application {
    @Override
    public void start(Stage stage) {

        Button Task_1 = new Button("Task_1");
        Button Task_2 = new Button("Task_2");
        Button Task_3 = new Button("Task_3");
        Button Task_4 = new Button("Task_4");


        VBox layout = new VBox(10, Task_1, Task_2, Task_3, Task_4);

        Scene scene = new Scene(layout, 300, 250);
        stage.setTitle("Выбор частей");


        Task_1.setOnAction(actionEvent -> {
            _MainApp1 main = new _MainApp1();
            main.start(new Stage());
            stage.close();
        });

        Task_2.setOnAction(actionEvent -> {
            HelloApplication1 main = new HelloApplication1();

            try {
                main.start(new Stage());
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            stage.close();
        });

        Task_3.setOnAction(actionEvent -> {
            HelloApplication main = new HelloApplication();
            try {
                main.start(new Stage());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            stage.close();
        });

        Task_4.setOnAction(actionEvent -> {
            _MainApp main = new _MainApp();
            main.start(new Stage());
            stage.close();
        });

        stage.setScene(scene);
        stage.show();
    }
    //нормальный дизайн; данные передаются не напрямую через базу данных, а через api
    public static void main(String[] args) {
        launch(args);
    }
}
