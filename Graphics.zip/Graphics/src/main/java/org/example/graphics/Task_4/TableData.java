package org.example.graphics.Task_4;

public record TableData (int id, String tablename) {
}
