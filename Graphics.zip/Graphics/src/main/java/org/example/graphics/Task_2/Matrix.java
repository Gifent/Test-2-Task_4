package org.example.graphics.Task_2;

public final class Matrix extends ArrayPy {
    public Matrix()
    {
    }

    public int[][] Production()
    {
        if ((array1 == null) || (array2 == null))
        {
            System.out.println("Нет матриц для перемножения!");
            return null;
        }

        int[][] result = new int[7][7];
        for (int i = 0; i < 7; i++) {
            for (int u = 0; u < 7; u++) {
                for (int j = 0; j < 7; j++) {
                    result[i][u] += array1[i][j] * array2[j][u];
                }
            }
        }
        return result;
    }
}

