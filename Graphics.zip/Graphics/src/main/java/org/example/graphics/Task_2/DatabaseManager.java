package org.example.graphics.Task_2;

import java.sql.*;
import java.util.*;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DatabaseManager {
    private Connection con;
    private List<String> tablelist = new ArrayList<>();
    private String currenttable = "";
    private String url;
    private String user;
    private String password;

    public DatabaseManager(String user, String password) {
        this.url = "jdbc:postgresql://localhost:5432/postgres";
        this.user = user;
        this.password = password;
    }

    public void connect() throws SQLException {
        con = DriverManager.getConnection(url, user, password);
        loadExistingTables();
    }

    private void loadExistingTables() throws SQLException {
        DatabaseMetaData metaData = con.getMetaData();
        ResultSet rs = metaData.getTables(null, null, "%", new String[]{"TABLE"});

        while (rs.next()) {
            String tableName = rs.getString("TABLE_NAME");
            if (!tablelist.contains(tableName)) {
                tablelist.add(tableName);
            }
        }
    }

    public void createCalculationsTable(String tablename) throws SQLException {
        String sql = String.format("""
                    CREATE TABLE IF NOT EXISTS %s (
                        id SERIAL PRIMARY KEY,
                        array_data1 VARCHAR(5000) NOT NULL,
                        array_data2 VARCHAR(5000) NOT NULL,
                        result VARCHAR(5000),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """, tablename);

        try (Statement stmt = con.createStatement()) {
            stmt.executeUpdate(sql);

            if (!tablelist.contains(tablename)) {
                tablelist.add(tablename);
            }

            currenttable = tablename;
            System.out.println("Таблица '" + tablename + "' создана");
        }
    }

    public void saveCalculation(String array1, String array2, String result) throws SQLException {

        String sql = String.format("""
                    INSERT INTO %s (array_data1, array_data2, result)
                    VALUES (?, ?, ?)
                """, currenttable);

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, array1);
            pstmt.setString(2, array2);
            pstmt.setString(3, result);

            pstmt.executeUpdate();
        }
    }

    public List<String> getTablesList() {
        return new ArrayList<>(tablelist);
    }

    public String getCurrentTable() {
        return currenttable;
    }

    public void setCurrentTable(String tableName) {
        if (tablelist.contains(tableName)) {
            currenttable = tableName;
        }
    }

    private class CalculationRecord {
        private int id;
        private String array1;
        private String array2;
        private String result;
        private Timestamp createdAt;

        public CalculationRecord(int id, String array1, String array2, String result,
                                 Timestamp createdAt) {
            this.id = id;
            this.array1 = array1;
            this.array2 = array2;
            this.result = result;
            this.createdAt = createdAt;
        }

        public int getId() {
            return id;
        }

        public String getArray1() {
            return array1;
        }

        public String getArray2() {
            return array2;
        }

        public String getResult() {
            return result;
        }

        public Timestamp getCreatedAt() {
            return createdAt;
        }
    }

    private List<CalculationRecord> getCalculationsFromTable(String tableName) throws SQLException {
        List<CalculationRecord> records = new ArrayList<>();

        String sql = "SELECT * FROM " + tableName + " ORDER BY id";

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CalculationRecord record = new CalculationRecord(
                        rs.getInt("id"),
                        rs.getString("array_data1"),
                        rs.getString("array_data2"),
                        rs.getString("result"),
                        rs.getTimestamp("created_at")
                );
                records.add(record);
            }
        }

        return records;
    }

    public void exportAllTablesToExcel() {
        try (Workbook workbook = new XSSFWorkbook()) {

            for (String tableName : tablelist) {
                createExcelSheet(workbook, tableName);
            }

            new File("exports").mkdirs();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String timestamp = dateFormat.format(new Date());
            String filename = "exports/calculations_" + timestamp + ".xlsx";

            try (FileOutputStream fos = new FileOutputStream(filename)) {
                workbook.write(fos);
                System.out.println("Все таблицы экспортированы в: " + filename);
            }

        } catch (Exception e) {
            System.out.println("Ошибка экспорта в Excel: " + e.getMessage());
        }
    }

    private void createExcelSheet(Workbook workbook, String tableName) {
        Sheet sheet = workbook.createSheet(tableName);

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("ID");
        headerRow.createCell(1).setCellValue("Матрица 1");
        headerRow.createCell(2).setCellValue("Матрица 2");
        headerRow.createCell(3).setCellValue("Результат");
        headerRow.createCell(4).setCellValue("Дата");

        try {
            List<CalculationRecord> data = getCalculationsFromTable(tableName);
            int rowNum = 1;

            for (CalculationRecord record : data) {
                String matrix1 = record.getArray1();
                String matrix2 = record.getArray2();
                String result = record.getResult();
                String[] matrix1Rows = matrix1 != null ? matrix1.split("\n") : new String[0];
                String[] matrix2Rows = matrix2 != null ? matrix2.split("\n") : new String[0];
                String[] resultRows = result != null ? result.split("\n") : new String[0];

                int maxRows = Math.max(matrix1Rows.length,
                        Math.max(matrix2Rows.length, resultRows.length));

                int startRow = rowNum;
                int endRow = rowNum + maxRows - 1;
                for (int i = 0; i < maxRows; i++) {
                    Row row = sheet.createRow(rowNum++);

                    if (i < matrix1Rows.length) {
                        row.createCell(1).setCellValue(matrix1Rows[i].trim());
                    }

                    if (i < matrix2Rows.length) {
                        row.createCell(2).setCellValue(matrix2Rows[i].trim());
                    }

                    if (i < resultRows.length) {
                        row.createCell(3).setCellValue(resultRows[i].trim());
                    }
                }

                Row firstRow = sheet.getRow(startRow);
                firstRow.createCell(0).setCellValue(record.getId());
                firstRow.createCell(4).setCellValue(record.getCreatedAt() != null ?
                        record.getCreatedAt().toString() : "");

                if (maxRows > 1) {
                    sheet.addMergedRegion(new CellRangeAddress(startRow, endRow, 0, 0));
                    sheet.addMergedRegion(new CellRangeAddress(startRow, endRow, 4, 4));
                }

                rowNum++;
            }

            for (int i = 0; i < 5; i++) {
                sheet.autoSizeColumn(i);
            }

        } catch (SQLException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    public void printAllTables() throws SQLException {
        System.out.println("Таблицы:");
        for (String tableName : tablelist) {
            System.out.println(tableName);
        }
    }

    private int getLastCalculationId() throws SQLException {
        String sql = String.format("""
                    SELECT id FROM %s 
                    ORDER BY id DESC 
                    LIMIT 1
                """, currenttable);

        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    public void updateCalculation(String newArray) throws SQLException {
        int id = getLastCalculationId();
        String sql = String.format("""
                    UPDATE %s 
                    SET result = ?, created_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                """, currenttable);

        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, newArray);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        }
    }
}