package org.example.graphics.Task_4;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.example.graphics.Task_4._MainApp.showAlert;
import static org.example.graphics.Task_4.ConnectionDB_.con;

public class OutputInformation {
    public static void show() throws SQLException {
        if (CreateDB.getTableon()) {
            try (Statement stmt = con.createStatement()) {
                String query = "SELECT * FROM " + CreateDB.getTablename();
                ResultSet rs = stmt.executeQuery(query);

                ObservableList<Data> tablelist = FXCollections.observableArrayList();

                int id = 1;
                while (rs.next()) {
                    tablelist.add(new Data(id++, rs.getString("NAME"), rs.getInt("AGE"), rs.getInt("SALARY")));
                }

                TableView<Data> tableView = new TableView<>();
                tableView.setItems(tablelist);

                TableColumn<Data, Integer> idColumn = new TableColumn<>("id");
                TableColumn<Data, String> nameColumn = new TableColumn<>("name");
                TableColumn<Data, Integer> ageColumn = new TableColumn<>("age");
                TableColumn<Data, Integer> salaryColumn = new TableColumn<>("salary");

                idColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().id()));
                nameColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().name()));
                ageColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().age()));
                salaryColumn.setCellValueFactory(celldata -> new ReadOnlyObjectWrapper<>(celldata.getValue().salary()));

                tableView.getColumns().addAll(idColumn, nameColumn, ageColumn, salaryColumn);

                Stage window = new Stage();
                window.setTitle("Информация");
                Scene scene = new Scene(tableView);
                window.setScene(scene);
                window.showAndWait();
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Таблица не создана");
        }
    }
}
