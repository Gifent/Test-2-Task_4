package org.example.graphics.Task_4;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;

public class _MainApp extends Application {
    public static void showAlert(Alert.AlertType alertType, String tittle, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(tittle);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public void start(Stage stage){
        ConnectionDB_.connect();
        stage.setTitle("Task №4");

        Button one = new Button("Вывести названия");
        Button two = new Button("Создать таблицу");
        Button three = new Button("Информация о студенте");
        Button four = new Button("Вывести информацию о таблице");
        Button five = new Button("Сохранить");

        three.setDisable(true);
        four.setDisable(true);
        five.setDisable(true);

        VBox layout = new VBox(10, one, two, three, four, five);
        Scene scene = new Scene(layout, 300, 240);
        stage.setScene(scene);
        stage.show();

        one.setOnAction(actionEvent -> {
            try {
                OutputNames.display();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        two.setOnAction(actionEvent -> {
            try {
                CreateDB.create();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            three.setDisable(false);
            four.setDisable(false);
            five.setDisable(false);
        });

        three.setOnAction(actionEvent -> {
            try {
                StudentInformation student = new StudentInformation();
                student.inf();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        four.setOnAction(actionEvent -> {
            try {
                OutputInformation.show();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        five.setOnAction(actionEvent -> {
            try {
                SaveDB.save();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }
}
