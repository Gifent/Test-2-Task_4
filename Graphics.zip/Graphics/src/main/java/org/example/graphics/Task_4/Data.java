package org.example.graphics.Task_4;

public record Data (int id, String name, int age, int salary){
}
